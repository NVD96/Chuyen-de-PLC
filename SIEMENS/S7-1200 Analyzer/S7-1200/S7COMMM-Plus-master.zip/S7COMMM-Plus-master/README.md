# s7comm_wireshark
Clone of S7comm Wireshark dissector by Thomas W. to (propably) fix building problems on Linux.

## Original description
Wireshark dissector for S7 communication. This Wireshark dissector plugin (dll) dissects the ISOonTCP-packets for communication to Siemens S7 PLCs.

## Original sources
The latest version of the Wireshark dissector can be downloaded from sourcforge:
[S7comm Wireshark dissector plugin](https://sourceforge.net/projects/s7commwireshark)

## Original author
[Thomas W.](https://sourceforge.net/u/userid-2377316/profile/) 
