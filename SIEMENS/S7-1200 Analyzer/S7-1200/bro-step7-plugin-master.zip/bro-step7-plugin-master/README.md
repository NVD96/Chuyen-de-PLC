
## Siemens S7 protocol analyzer plugin

This is a proof of concept implementation of the Siemens S7 protocol analyser for the Bro IDS. It support the s7-300, s7-400, s7-1200 series PLC communication and partially some other Siemens products as well.
This plugin was part of a larger project and was rapidly developed as a PoC which is reflected on the quality of the code.

#### Disclaimer

**The analyzer is not intended nor suitable to be used in a production environment it comes without any expressed or implied warranty of fitness for any particular purpose.
The authors do not take responsibility for any damage or loss caused by this piece of software.**

It is released in a hope that one might find it useful when implementing a production ready S7 analyzer.

#### Usage

See the [bro documentation](https://www.bro.org/sphinx-git/devel/plugins.htms) for detailed information on how to install analyzer plugins.
