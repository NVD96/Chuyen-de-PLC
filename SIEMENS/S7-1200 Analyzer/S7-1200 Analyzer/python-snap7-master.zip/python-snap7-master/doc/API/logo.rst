Logo
====

.. autoclass:: snap7.logo.Logo
   :members:
