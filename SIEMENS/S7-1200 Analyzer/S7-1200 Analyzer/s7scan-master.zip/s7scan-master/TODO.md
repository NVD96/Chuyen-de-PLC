[ ] 1.  Integrate winpcap_installer with s7scan
[ ] 2.  Too large executable on Linux
[ ] 3.  Add saving scan state (for large networks)
[ ] 4.  Match IP scan and LLC scan (IP to MAC correlation)