## S7-pcaps

These are some pcaps I have created for public use. The traffic is recorded between various client applications (STEP7 Manager 5.5, TIA Portal v13, Custom client with [Snap7](http://snap7.sourceforge.net/), WinCC Advanced) and s7-300 and s7-400 series PLCs. 

The IPs are randomized and rewritten with TCP rewrite, so please don't try to look for these devices on the internet (they are not in public networks anyways). 
