namespace S7.Net.UnitTest;

internal record RequestResponsePair(string RequestPattern, string ResponsePattern);
