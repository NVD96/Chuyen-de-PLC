﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace S7.UnitTest.Helpers
{
    /// <summary>
    /// This is a struct that contains more than 200 bytes and that needs 2 plc requests to complete a read/write cycle
    /// </summary>
    struct TestLongStruct
    {
        // these variables are not used, but are needed to match the size of the DB
#pragma warning disable 0649


        public short IntVariable0;
        public short IntVariable1;
        public short IntVariable2;
        public short IntVariable3;
        public short IntVariable4;
        public short IntVariable5;
        public short IntVariable6;
        public short IntVariable7;
        public short IntVariable8;
        public short IntVariable9;

        public short IntVariable10;
        public short IntVariable11;
        public short IntVariable12;
        public short IntVariable13;
        public short IntVariable14;
        public short IntVariable15;
        public short IntVariable16;
        public short IntVariable17;
        public short IntVariable18;
        public short IntVariable19;

        public short IntVariable20;
        public short IntVariable21;
        public short IntVariable22;
        public short IntVariable23;
        public short IntVariable24;
        public short IntVariable25;
        public short IntVariable26;
        public short IntVariable27;
        public short IntVariable28;
        public short IntVariable29;

        public short IntVariable30;
        public short IntVariable31;
        public short IntVariable32;
        public short IntVariable33;
        public short IntVariable34;
        public short IntVariable35;
        public short IntVariable36;
        public short IntVariable37;
        public short IntVariable38;
        public short IntVariable39;

        public short IntVariable40;
        public short IntVariable41;
        public short IntVariable42;
        public short IntVariable43;
        public short IntVariable44;
        public short IntVariable45;
        public short IntVariable46;
        public short IntVariable47;
        public short IntVariable48;
        public short IntVariable49;

        public short IntVariable50;
        public short IntVariable51;
        public short IntVariable52;
        public short IntVariable53;
        public short IntVariable54;
        public short IntVariable55;
        public short IntVariable56;
        public short IntVariable57;
        public short IntVariable58;
        public short IntVariable59;

        public short IntVariable60;
        public short IntVariable61;
        public short IntVariable62;
        public short IntVariable63;
        public short IntVariable64;
        public short IntVariable65;
        public short IntVariable66;
        public short IntVariable67;
        public short IntVariable68;
        public short IntVariable69;

        public short IntVariable70;
        public short IntVariable71;
        public short IntVariable72;
        public short IntVariable73;
        public short IntVariable74;
        public short IntVariable75;
        public short IntVariable76;
        public short IntVariable77;
        public short IntVariable78;
        public short IntVariable79;

        public short IntVariable80;
        public short IntVariable81;
        public short IntVariable82;
        public short IntVariable83;
        public short IntVariable84;
        public short IntVariable85;
        public short IntVariable86;
        public short IntVariable87;
        public short IntVariable88;
        public short IntVariable89;

        public short IntVariable90;
        public short IntVariable91;
        public short IntVariable92;
        public short IntVariable93;
        public short IntVariable94;
        public short IntVariable95;
        public short IntVariable96;
        public short IntVariable97;
        public short IntVariable98;
        public short IntVariable99;

        public short IntVariable100;
        public short IntVariable101;
        public short IntVariable102;
        public short IntVariable103;
        public short IntVariable104;
        public short IntVariable105;
        public short IntVariable106;
        public short IntVariable107;
        public short IntVariable108;
        public short IntVariable109;

        public short IntVariable110;
        public short IntVariable111;
        public short IntVariable112;
        public short IntVariable113;
        public short IntVariable114;
        public short IntVariable115;
        public short IntVariable116;
        public short IntVariable117;
        public short IntVariable118;
        public short IntVariable119;

#pragma warning restore 0649

    }
}
