# Four-layer-elevator-experiment-program-realized-by-Mitsubishi-PLC
三菱PLC实现的四层电梯实验程序 Four-layer elevator experiment program realized by Mitsubishi PLC

请先安装三菱plc编程专用软件GX Developer
需要使用GX Developer打开
