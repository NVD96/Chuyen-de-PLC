PLClib Library
FX5U , Q Series
https://youtu.be/sK4dDKF22oM
https://youtu.be/8Lndbb9Byjk
------------------------------
Trial version  30 days
Total Read Maximum 5 data
Contact Mr.Kriengsak Inban
Tel:(+66)093167339
Email:inbankriengsak@gmail.com ,kriengsak.inban@hotmail.com
Line:@cbtline
------------------------------