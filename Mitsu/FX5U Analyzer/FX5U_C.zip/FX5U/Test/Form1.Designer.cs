﻿namespace Test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Connect = new System.Windows.Forms.Button();
            this.Disconnect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.la_Status = new System.Windows.Forms.Label();
            this.txtD1 = new System.Windows.Forms.TextBox();
            this.txtD0 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtM1 = new System.Windows.Forms.TextBox();
            this.txtM0 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Write_D1 = new System.Windows.Forms.Button();
            this.Write_D0 = new System.Windows.Forms.Button();
            this.txt_D1 = new System.Windows.Forms.TextBox();
            this.txt_D0 = new System.Windows.Forms.TextBox();
            this.M1_ON = new System.Windows.Forms.Button();
            this.M0_ON = new System.Windows.Forms.Button();
            this.M1_OFF = new System.Windows.Forms.Button();
            this.M0_OFF = new System.Windows.Forms.Button();
            this.tmrScan = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // Connect
            // 
            this.Connect.Location = new System.Drawing.Point(27, 25);
            this.Connect.Name = "Connect";
            this.Connect.Size = new System.Drawing.Size(152, 42);
            this.Connect.TabIndex = 0;
            this.Connect.Text = "Connect";
            this.Connect.UseVisualStyleBackColor = true;
            this.Connect.Click += new System.EventHandler(this.Connect_Click);
            // 
            // Disconnect
            // 
            this.Disconnect.Location = new System.Drawing.Point(27, 82);
            this.Disconnect.Name = "Disconnect";
            this.Disconnect.Size = new System.Drawing.Size(152, 42);
            this.Disconnect.TabIndex = 1;
            this.Disconnect.Text = "DisConnect";
            this.Disconnect.UseVisualStyleBackColor = true;
            this.Disconnect.Click += new System.EventHandler(this.Disconnect_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(210, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "IP Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(210, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Port";
            // 
            // txtIP
            // 
            this.txtIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIP.Location = new System.Drawing.Point(324, 42);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(176, 30);
            this.txtIP.TabIndex = 4;
            this.txtIP.Text = "192.168.209.111";
            this.txtIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPort
            // 
            this.txtPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPort.Location = new System.Drawing.Point(324, 88);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(176, 30);
            this.txtPort.TabIndex = 5;
            this.txtPort.Text = "8000";
            this.txtPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(558, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Status";
            // 
            // la_Status
            // 
            this.la_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la_Status.Location = new System.Drawing.Point(660, 60);
            this.la_Status.Name = "la_Status";
            this.la_Status.Size = new System.Drawing.Size(179, 44);
            this.la_Status.TabIndex = 7;
            this.la_Status.Text = "DisConnect";
            this.la_Status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtD1
            // 
            this.txtD1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtD1.Location = new System.Drawing.Point(324, 266);
            this.txtD1.Name = "txtD1";
            this.txtD1.Size = new System.Drawing.Size(176, 30);
            this.txtD1.TabIndex = 11;
            this.txtD1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtD0
            // 
            this.txtD0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtD0.Location = new System.Drawing.Point(324, 220);
            this.txtD0.Name = "txtD0";
            this.txtD0.Size = new System.Drawing.Size(176, 30);
            this.txtD0.TabIndex = 10;
            this.txtD0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(210, 266);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "D1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(210, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "D0";
            // 
            // txtM1
            // 
            this.txtM1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtM1.Location = new System.Drawing.Point(324, 391);
            this.txtM1.Name = "txtM1";
            this.txtM1.Size = new System.Drawing.Size(176, 30);
            this.txtM1.TabIndex = 15;
            this.txtM1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtM0
            // 
            this.txtM0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtM0.Location = new System.Drawing.Point(324, 345);
            this.txtM0.Name = "txtM0";
            this.txtM0.Size = new System.Drawing.Size(176, 30);
            this.txtM0.TabIndex = 14;
            this.txtM0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(210, 391);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "M1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(210, 345);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 25);
            this.label7.TabIndex = 12;
            this.label7.Text = "M0";
            // 
            // Write_D1
            // 
            this.Write_D1.Location = new System.Drawing.Point(536, 265);
            this.Write_D1.Name = "Write_D1";
            this.Write_D1.Size = new System.Drawing.Size(152, 42);
            this.Write_D1.TabIndex = 17;
            this.Write_D1.Text = "Write D1";
            this.Write_D1.UseVisualStyleBackColor = true;
            this.Write_D1.Click += new System.EventHandler(this.Write_D1_Click);
            // 
            // Write_D0
            // 
            this.Write_D0.Location = new System.Drawing.Point(536, 208);
            this.Write_D0.Name = "Write_D0";
            this.Write_D0.Size = new System.Drawing.Size(152, 42);
            this.Write_D0.TabIndex = 16;
            this.Write_D0.Text = "Write D0";
            this.Write_D0.UseVisualStyleBackColor = true;
            this.Write_D0.Click += new System.EventHandler(this.Write_D0_Click);
            // 
            // txt_D1
            // 
            this.txt_D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_D1.Location = new System.Drawing.Point(711, 263);
            this.txt_D1.Name = "txt_D1";
            this.txt_D1.Size = new System.Drawing.Size(176, 30);
            this.txt_D1.TabIndex = 19;
            this.txt_D1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_D0
            // 
            this.txt_D0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_D0.Location = new System.Drawing.Point(711, 217);
            this.txt_D0.Name = "txt_D0";
            this.txt_D0.Size = new System.Drawing.Size(176, 30);
            this.txt_D0.TabIndex = 18;
            this.txt_D0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // M1_ON
            // 
            this.M1_ON.Location = new System.Drawing.Point(536, 396);
            this.M1_ON.Name = "M1_ON";
            this.M1_ON.Size = new System.Drawing.Size(152, 42);
            this.M1_ON.TabIndex = 21;
            this.M1_ON.Text = "M1 ON";
            this.M1_ON.UseVisualStyleBackColor = true;
            this.M1_ON.Click += new System.EventHandler(this.M1_ON_Click);
            // 
            // M0_ON
            // 
            this.M0_ON.Location = new System.Drawing.Point(536, 339);
            this.M0_ON.Name = "M0_ON";
            this.M0_ON.Size = new System.Drawing.Size(152, 42);
            this.M0_ON.TabIndex = 20;
            this.M0_ON.Text = "M0 ON";
            this.M0_ON.UseVisualStyleBackColor = true;
            this.M0_ON.Click += new System.EventHandler(this.M0_ON_Click);
            // 
            // M1_OFF
            // 
            this.M1_OFF.Location = new System.Drawing.Point(711, 396);
            this.M1_OFF.Name = "M1_OFF";
            this.M1_OFF.Size = new System.Drawing.Size(152, 42);
            this.M1_OFF.TabIndex = 23;
            this.M1_OFF.Text = "M1 OFF";
            this.M1_OFF.UseVisualStyleBackColor = true;
            this.M1_OFF.Click += new System.EventHandler(this.M1_OFF_Click);
            // 
            // M0_OFF
            // 
            this.M0_OFF.Location = new System.Drawing.Point(711, 339);
            this.M0_OFF.Name = "M0_OFF";
            this.M0_OFF.Size = new System.Drawing.Size(152, 42);
            this.M0_OFF.TabIndex = 22;
            this.M0_OFF.Text = "M0 OFF";
            this.M0_OFF.UseVisualStyleBackColor = true;
            this.M0_OFF.Click += new System.EventHandler(this.M0_OFF_Click);
            // 
            // tmrScan
            // 
            this.tmrScan.Tick += new System.EventHandler(this.tmrScan_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 626);
            this.Controls.Add(this.M1_OFF);
            this.Controls.Add(this.M0_OFF);
            this.Controls.Add(this.M1_ON);
            this.Controls.Add(this.M0_ON);
            this.Controls.Add(this.txt_D1);
            this.Controls.Add(this.txt_D0);
            this.Controls.Add(this.Write_D1);
            this.Controls.Add(this.Write_D0);
            this.Controls.Add(this.txtM1);
            this.Controls.Add(this.txtM0);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtD1);
            this.Controls.Add(this.txtD0);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.la_Status);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPort);
            this.Controls.Add(this.txtIP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Disconnect);
            this.Controls.Add(this.Connect);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Connect;
        private System.Windows.Forms.Button Disconnect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label la_Status;
        private System.Windows.Forms.TextBox txtD1;
        private System.Windows.Forms.TextBox txtD0;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtM1;
        private System.Windows.Forms.TextBox txtM0;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button Write_D1;
        private System.Windows.Forms.Button Write_D0;
        private System.Windows.Forms.TextBox txt_D1;
        private System.Windows.Forms.TextBox txt_D0;
        private System.Windows.Forms.Button M1_ON;
        private System.Windows.Forms.Button M0_ON;
        private System.Windows.Forms.Button M1_OFF;
        private System.Windows.Forms.Button M0_OFF;
        private System.Windows.Forms.Timer tmrScan;
    }
}

