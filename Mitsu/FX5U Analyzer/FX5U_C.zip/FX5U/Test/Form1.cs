﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PLClib;
namespace Test
{
    public partial class Form1 : Form
    {
        libPLC PLC = new libPLC();
        String[] Get_Bit;
        String[] Get_DWord;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Connect_Click(object sender, EventArgs e)
        {
            if(PLC.IsConnected() == false)
            {
                PLC.Connect(txtIP.Text, Int16.Parse(txtPort.Text));
                if (PLC.IsConnected() == true)
                {
                    la_Status.Text = "Connect";
                    tmrScan.Start();
                }
            }
        }

        private void Disconnect_Click(object sender, EventArgs e)
        {
            if(PLC.IsConnected() == true)
            {
                PLC.DisConnect();
                la_Status.Text = "DisConnect";
                tmrScan.Stop();
            }
        }

        private void tmrScan_Tick(object sender, EventArgs e)
        {
            Get_Bit = PLC.BitRead("M", 0, 2);
            Get_DWord = PLC.WordRead("D", 0, 2);
            txtD0.Text = Get_DWord[0];
            txtD1.Text = Get_DWord[1];
            txtM0.Text = Get_Bit[0];
            txtM1.Text = Get_Bit[1];
        }

        private void Write_D0_Click(object sender, EventArgs e)
        {
            if(txt_D0.Text  != "")
            {
                PLC.WordWrite("D", 0, Int32.Parse(txt_D0.Text));
                if(PLC.LastErrorCode() == 0)
                {
                    txt_D0.Text = "";
                }
            }
        }

        private void Write_D1_Click(object sender, EventArgs e)
        {
            if (txt_D1.Text != "")
            {
                PLC.WordWrite("D", 1, Int32.Parse(txt_D1.Text));
                if (PLC.LastErrorCode() == 0)
                {
                    txt_D1.Text = "";
                }
            }
        }

        private void M0_ON_Click(object sender, EventArgs e)
        {
            PLC.BitWrite("M", 0, 1);
        }

        private void M0_OFF_Click(object sender, EventArgs e)
        {
            PLC.BitWrite("M", 0, 0);
        }

        private void M1_ON_Click(object sender, EventArgs e)
        {
            PLC.BitWrite("M", 1, 1);
        }

        private void M1_OFF_Click(object sender, EventArgs e)
        {
            PLC.BitWrite("M", 1, 0);
        }
    }
}
