﻿namespace IndustrialNetworks.FatekApp
{
    partial class FormWriteToRegisters
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtWM32 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtWM33 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtWM34 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtWM35 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtWM36 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtWM37 = new System.Windows.Forms.TextBox();
            this.btnWrite = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "WM32";
            // 
            // txtWM32
            // 
            this.txtWM32.Location = new System.Drawing.Point(51, 12);
            this.txtWM32.Name = "txtWM32";
            this.txtWM32.Size = new System.Drawing.Size(100, 22);
            this.txtWM32.TabIndex = 1;
            this.txtWM32.Text = "1982";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(168, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "WM33";
            // 
            // txtWM33
            // 
            this.txtWM33.Location = new System.Drawing.Point(213, 12);
            this.txtWM33.Name = "txtWM33";
            this.txtWM33.Size = new System.Drawing.Size(100, 22);
            this.txtWM33.TabIndex = 1;
            this.txtWM33.Text = "12009";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(327, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "WM34";
            // 
            // txtWM34
            // 
            this.txtWM34.Location = new System.Drawing.Point(372, 12);
            this.txtWM34.Name = "txtWM34";
            this.txtWM34.Size = new System.Drawing.Size(100, 22);
            this.txtWM34.TabIndex = 1;
            this.txtWM34.Text = "65535";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "WM35";
            // 
            // txtWM35
            // 
            this.txtWM35.Location = new System.Drawing.Point(51, 40);
            this.txtWM35.Name = "txtWM35";
            this.txtWM35.Size = new System.Drawing.Size(100, 22);
            this.txtWM35.TabIndex = 1;
            this.txtWM35.Text = "1983";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(168, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "WM36";
            // 
            // txtWM36
            // 
            this.txtWM36.Location = new System.Drawing.Point(213, 40);
            this.txtWM36.Name = "txtWM36";
            this.txtWM36.Size = new System.Drawing.Size(100, 22);
            this.txtWM36.TabIndex = 1;
            this.txtWM36.Text = "1993";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(327, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "WM37";
            // 
            // txtWM37
            // 
            this.txtWM37.Location = new System.Drawing.Point(372, 40);
            this.txtWM37.Name = "txtWM37";
            this.txtWM37.Size = new System.Drawing.Size(100, 22);
            this.txtWM37.TabIndex = 1;
            this.txtWM37.Text = "2013";
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(51, 68);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(100, 35);
            this.btnWrite.TabIndex = 2;
            this.btnWrite.Text = "WRITE";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // FormWriteToRegisters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 113);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.txtWM37);
            this.Controls.Add(this.txtWM34);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtWM36);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtWM33);
            this.Controls.Add(this.txtWM35);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtWM32);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormWriteToRegisters";
            this.Text = "Write to continuous registers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtWM32;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtWM33;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtWM34;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtWM35;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtWM36;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.TextBox txtWM37;
    }
}