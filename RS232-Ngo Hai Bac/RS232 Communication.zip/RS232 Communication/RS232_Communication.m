function varargout = RS232_Communication(varargin)
% RS232_COMMUNICATION M-file for RS232_Communication.fig
%      RS232_COMMUNICATION, by itself, creates a new RS232_COMMUNICATION or raises the existing
%      singleton*.
%
%      H = RS232_COMMUNICATION returns the handle to a new
%      RS232_COMMUNICATION or the handle to
%      the existing singleton*.
%
%      RS232_COMMUNICATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RS232_COMMUNICATION.M with the given input arguments.
%
%      RS232_COMMUNICATION('Property','Value',...) creates a new RS232_COMMUNICATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RS232_Communication_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RS232_Communication_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help RS232_Communication

% Last Modified by GUIDE v2.5 26-Dec-2006 01:49:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RS232_Communication_OpeningFcn, ...
                   'gui_OutputFcn',  @RS232_Communication_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before RS232_Communication is made visible.
function RS232_Communication_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RS232_Communication (see VARARGIN)

% Choose default command line output for RS232_Communication
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes RS232_Communication wait for user response (see UIRESUME)
% uiwait(handles.figure1);


%manual Ngo Hai Bac
set(handles.edit_TX,'String','');
set(handles.edit_RX,'String','');
set(handles.edit_StatusConnect,'String','Disconnect');
set(handles.edit_StatusSend,'String','');


set(handles.edit_TX,'HorizontalAlignment','Left');
set(handles.edit_RX,'HorizontalAlignment','Left');


set(handles.button_Send,'String','Send');
set(handles.button_Exit,'String','Exit');
set(handles.button_ClearTX,'String','Clear TX');
set(handles.button_ClearRX,'String','Clear RX');

set(handles.button_Connect,'String','Connect');
IsConnect = 0;  % 1 = Connect,0 = Disconnect
save data ;
% Initalize for RS232 Object


% --- Outputs from this function are returned to the command line.
function varargout = RS232_Communication_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;





function edit_RX_Callback(hObject, eventdata, handles)
% hObject    handle to edit_RX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_RX as text
%        str2double(get(hObject,'String')) returns contents of edit_RX as a double


% --- Executes during object creation, after setting all properties.
function edit_RX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_RX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit_TX_Callback(hObject, eventdata, handles)
% hObject    handle to edit_TX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_TX as text
%        str2double(get(hObject,'String')) returns contents of edit_TX as a double


% --- Executes during object creation, after setting all properties.
function edit_TX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_TX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes on button press in button_Send.
function button_Send_Callback(hObject, eventdata, handles)
% hObject    handle to button_Send (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load data ;
if (IsConnect == 1)
    set(handles.edit_StatusSend,'String','Sending... ');
    strTX = get(handles.edit_TX,'String');
   
    fprintf(s,strTX);
    set(handles.edit_StatusSend,'String','Sent successfully ');
end

save data;



% --- Executes on button press in button_Exit.
function button_Exit_Callback(hObject, eventdata, handles)
% hObject    handle to button_Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
   user_response = modaldlg('Title','Exit');
    switch lower(user_response)
    case 'no'
        % do nothing
    case 'yes'
          load data;
          if (IsConnect == 1) 
              record(s,'off');
              fclose(s);
              clear s;
          end;
          save data;
          
          close(RS232_Communication);
    end



% --- Executes on button press in button_Connect.
function button_Connect_Callback(hObject, eventdata, handles)
% hObject    handle to button_Connect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load data;
if (IsConnect == 0), 
    
    IsConnect = 1;
    
    s = serial(get_stringPopup(handles.popup_ComPort));
    
    s.BaudRate = get_doublePopup(handles.popup_BaudRate);    
    s.DataBits = get_doublePopup(handles.popup_DataBit);
    s.Parity =   get_stringPopup(handles.popup_ParityBit);
    s.StopBit = get_doublePopup(handles.popup_StopBit);
    
    s.BytesAvailableFcnCount = 1;
    s.BytesAvailableFcnMode = 'terminator';
    
    s.BytesAvailableFcn = @BytesAvailable_Callback;
    s.OutputEmptyFcn =   @OutputEmpty_Callback;
    s.BreakInterruptFcn = @BreakInterrupt_Callback;
    s.ErrorFcn = @Error_Callback;
    s.PinStatusFcn = @PinStatus_Callback;
    s.BreakInterruptFcn = @BreakInterrupt_Callback;
    s.TimerFcn = @Timer_Callback;
    
    s.RecordName = get(handles.edit_RecordName,'String');s
    s.RecordMode = 'index';
      
    fopen(s);    
    
    record(s,'on')

        

    temp = s.status;
    
    if(temp == 'open'),
        set(handles.button_Connect,'String','Disconnect');
        set(handles.edit_StatusConnect,'String','Connected');
    else
        set(handles.edit_StatusConnect,'String','A Problem occour..');
    end;
    
    object = GCBO;
    save dataFig ;
    
    
    set(handles.popup_ComPort,'Enable','off');
    set(handles.popup_BaudRate,'Enable','off');
    set(handles.popup_DataBit,'Enable','off');
    set(handles.popup_StopBit,'Enable','off');
    set(handles.popup_ParityBit,'Enable','off');
    set(handles.edit_RecordName,'Enable','off');
    
        
else
    set(handles.button_Connect,'String','Connect');
    IsConnect = 0;
    set(handles.edit_StatusConnect,'String','Disconnected');
    record(s,'off')
    fclose(s);
    delete(s);
    
    
    set(handles.popup_ComPort,'Enable','on');
    set(handles.popup_BaudRate,'Enable','on');
    set(handles.popup_DataBit,'Enable','on');
    set(handles.popup_StopBit,'Enable','on');
    set(handles.popup_ParityBit,'Enable','on');
    set(handles.edit_RecordName,'Enable','on');
end 
save data;


%---------------------- Serial_Callback
function BytesAvailable_Callback(obj,event)
    ind = fscanf(obj); 
    
    load dataFig
    % Edit code here - Ngo Hai Bac
    
    set(handles.edit_RX,'String',ind);
    
    % End of edit
    save dataFig

%Specify the M-file callback function to execute when the output buffer is
%empty
function OutputEmpty_Callback(obj,event)


%Specify the M-file callback function to execute when an error event occurs
function Error_Callback(obj,event)
    load data;
    
    set(handles.edit_StatusSend,'Send Fail');
    save data;


%Specify the M-file callback function to execute when the CD, CTS, DSR, or
%RI pins change state
function PinStatus_Callback(obj,event)




%Specify the M-file callback function to execute
%when a predefined period of time passes
function Timer_Callback(obj,event)
    
    
% Function to 
function stringPopup = get_stringPopup(hObject,handles)
    val = get(hObject,'Value');
    string_list = get(hObject,'String');
    stringPopup = string_list{val}; % convert from cell array
                                    % to string
                                   
% Function to 
function doublePopup = get_doublePopup(hObject,handles)
    val = get(hObject,'Value');
    string_list = get(hObject,'String');
    selected_string = string_list{val}; % convert from cell array
                                    % to string
    doublePopup = str2double(selected_string);
% --- Executes on button press in button_ClearTX.


function button_ClearTX_Callback(hObject, eventdata, handles)
% hObject    handle to button_ClearTX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit_TX,'String','');

% --- Executes on button press in button_ClearRX.
function button_ClearRX_Callback(hObject, eventdata, handles)
% hObject    handle to button_ClearRX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit_RX,'String','');



%Specify the M-file callback function to execute when a break-interrupt
%event occurs
function BreakInterrupt_Callback(hObject, eventdata,handles)




% --- Executes during object deletion, before destroying properties.
function figure1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load data;
if (IsConnect == 1),
    record(s,'off')
    fclose(s);
    delete(s);
    clear s;
    IsConnect = 0;
end
save data


% --- Executes during object creation, after setting all properties.
function edit_StatusConnect_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_StatusConnect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function edit_StatusSend_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_StatusSend (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
load data;
if (IsConnect == 1),
    record(s,'off');
    fclose(s);
    delete(s);
    clear s;
    IsConnect = 0;
end

delete(hObject);




% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popup_ComPort.
function popup_ComPort_Callback(hObject, eventdata, handles)
% hObject    handle to popup_ComPort (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popup_ComPort contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_ComPort


% --- Executes during object creation, after setting all properties.
function popup_ComPort_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_ComPort (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popup_DataBit.
function popup_DataBit_Callback(hObject, eventdata, handles)
% hObject    handle to popup_DataBit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popup_DataBit contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_DataBit


% --- Executes during object creation, after setting all properties.
function popup_DataBit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_DataBit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popup_ParityBit.
function popup_ParityBit_Callback(hObject, eventdata, handles)
% hObject    handle to popup_ParityBit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popup_ParityBit contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_ParityBit


% --- Executes during object creation, after setting all properties.
function popup_ParityBit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_ParityBit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popup_BaudRate.
function popup_BaudRate_Callback(hObject, eventdata, handles)
% hObject    handle to popup_BaudRate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popup_BaudRate contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_BaudRate


% --- Executes during object creation, after setting all properties.
function popup_BaudRate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_BaudRate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popup_StopBit.
function popup_StopBit_Callback(hObject, eventdata, handles)
% hObject    handle to popup_StopBit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popup_StopBit contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_StopBit


% --- Executes during object creation, after setting all properties.
function popup_StopBit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_StopBit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenu6.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu6


% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function edit_RecordName_Callback(hObject, eventdata, handles)
% hObject    handle to edit_RecordName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_RecordName as text
%        str2double(get(hObject,'String')) returns contents of edit_RecordName as a double


% --- Executes during object creation, after setting all properties.
function edit_RecordName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_RecordName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on button press in button_About.
function button_About_Callback(hObject, eventdata, handles)
% hObject    handle to button_About (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    HelpPath = which('Help_PCCommunicationRS232.html');
    web(HelpPath); 

