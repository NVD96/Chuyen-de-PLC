﻿Public Class Form1
    Public TX As String
    Public FCS As String
    Public RXD As String
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Enabled = False
        'Display current date and time
        Label2.Text = System.DateTime.Now
        'Open the serial port
        If SerialPort1.IsOpen = False Then
            SerialPort1.Open()
        End If
        Dim charreturn As Integer
        'Check DM AREA DM0000 to DM0009 data update
        TX = "@00RD00000010"
        Call GetFCS()
        Label25.Text = TX + FCS + "*"
        Call communicate()
        SerialPort1.Close()
        ' Set information on the screen
        Label26.Text = RXD
        If RXD.Substring(5, 2) = "00" Then
            Label4.Text = RXD.Substring(7, 4)
            Label5.Text = RXD.Substring(11, 4)
            Label7.Text = RXD.Substring(15, 4)
            Label9.Text = RXD.Substring(19, 4)
            Label11.Text = RXD.Substring(23, 4)
            Label13.Text = RXD.Substring(27, 4)
            Label15.Text = RXD.Substring(31, 4)
            Label17.Text = RXD.Substring(35, 4)
            Label19.Text = RXD.Substring(39, 4)
            Label21.Text = RXD.Substring(43, 4)
        End If
        Timer1.Enabled = True
    End Sub
    Private Sub GetFCS()
        'This will calculate the FCS value for the communications
        Dim L As Integer
        Dim A As String
        Dim TJ As String
        L = Len(TX)
        A = 0
        For J = 1 To L
            TJ = Mid$(TX, J, 1)
            A = Asc(TJ) Xor A
        Next J
        FCS = Hex$(A)
        If Len(FCS) = 1 Then FCS = "0" + FCS
    End Sub
    Private Sub communicate()
        'This will communicate to the Omron PLC
        Dim BufferTX As String
        Dim fcs_rxd As String
        Try
            RXD = ""
            BufferTX = TX + FCS + "*" + Chr(13)
            'Send the information out the serial port
            SerialPort1.Write(BufferTX)
            'Sleep for 50 msec so the information can be sent on the port
            System.Threading.Thread.Sleep(50)
            'Set the timeout for the serial port at 100 msec
            SerialPort1.ReadTimeout = 100
            'Read up to the carriage return
            RXD = (SerialPort1.ReadTo(Chr(13)))
        Catch ex As Exception
            'If an error occurs then indicate communication error
            RXD = "Communication Error"
        End Try
        'Get the FCS of the returned information
        fcs_rxd = RXD.Substring(RXD.Length - 3, 2)
        If RXD.Substring(0, 1) = "@" Then
            TX = RXD.Substring(0, RXD.Length - 3)
        ElseIf RXD.Substring(2, 1) = "@" Then
            TX = RXD.Substring(2, RXD.Length - 5)
            RXD = RXD.Substring(2, RXD.Length - 1)
        End If
        'Check the FCS of the return information. If they are not the same then an error has occurred.
        Call GetFCS()
        If FCS <> fcs_rxd Then
            RXD = "Communication Error"
        End If

    End Sub


End Class
